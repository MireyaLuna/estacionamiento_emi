let tblUsuarios, tblVehiculos;
document.addEventListener("DOMContentLoaded", function () {
    tblUsuarios = $('#tblUsuarios').DataTable({
        ajax: {
            url: base_url + "Usuarios/listar",
            dataSrc: ''
        },
        columns: [{
            'data': 'id',
        }, {
            'data': 'usuario',
        }, {
            'data': 'nombre',
        }, {
            'data': 'genero',
        }, {
            'data': 'cargo',
        }, {
            'data': 'fecha_creacion',
        }, {
            // 'data': 'usuario_creacion',
            // }, {
            'data': 'fecha_modificacion',
        }, {
            // 'data': 'usuario_modificador',
            // }, {
            'data': 'estado',
        }, {
            'data': 'acciones',
        }]
    });
})
function frmLogin(e) {
    e.preventDefault();
    const usuario = document.getElementById("usuario");
    const clave = document.getElementById("clave");
    if (usuario.value == "") {
        clave.classList.remove("is-invalid");
        usuario.classList.add("is-invalid");
        usuario.focus();
    } else if (clave.value == "") {
        usuario.classList.remove("is-invalid");
        clave.classList.add("is-invalid");
        clave.focus();
    } else {
        const url = base_url + "Usuarios/validar";
        const frm = document.getElementById("frmLogin");
        const http = new XMLHttpRequest();
        http.open("POST", url, true);
        http.send(new FormData(frm));
        http.onreadystatechange = function () {
            if (this.readyState == 4 && this.status == 200) {
                // console.log(this.responseText);
                const res = JSON.parse(this.responseText);
                if (res == "ok") {
                    window.location = base_url + "Usuarios";
                } else {
                    document.getElementById("alerta").classList.remove("d-none");
                    document.getElementById("alerta").innerHTML = res;
                }
            }
        }
    }
}
function frmUsuario() {
    document.getElementById("tituloModal").innerHTML = "Registrar usuario";
    document.getElementById("btnAccion").innerHTML = "Registrar";
    document.getElementById("claves").classList.remove('d-none');
    document.getElementById("frmUsuario").reset();
    $("#nuevo_usuario").modal("show");
    document.getElementById("id").value = "";
}
function registrarUsuario(e) {
    e.preventDefault();
    const usuario = document.getElementById("usuario");
    const nombre = document.getElementById("nombre");
    const clave = document.getElementById("clave");
    const confirmar = document.getElementById("confirmar");
    const genero = document.getElementById("genero");
    const cargo = document.getElementById("cargo");
    if (usuario.value == "" || nombre.value == "" || genero.value == ""|| cargo.value == "") {
        alertas('Todo los campos son obligatorios', 'warning');
    } else if (clave.value != confirmar.value) {
        alertas('Las contraseñas no coinciden', 'warning');
    } else {
        const url = base_url + "Usuarios/registrar";
        const frm = document.getElementById("frmUsuario");
        const http = new XMLHttpRequest();
        http.open("POST", url, true);
        http.send(new FormData(frm));
        http.onreadystatechange = function () {
            if (this.readyState == 4 && this.status == 200) {
                const res = JSON.parse(this.responseText);
                alertas(res.msg, res.icono);
                frm.reset();
                $("#nuevo_usuario").modal("hide");
                tblUsuarios.ajax.reload();
            }
        }
    }
}
function btnEditarUsuario(id) {
    document.getElementById("tituloModal").innerHTML = "Actualizar usuario";
    document.getElementById("btnAccion").innerHTML = "Modificar";
    const url = base_url + "Usuarios/editar/" + id;
    const http = new XMLHttpRequest();
    http.open("GET", url, true);
    http.send();
    http.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
            const res = JSON.parse(this.responseText);
            // if (res=='') {
            //     alertas("No tiene permiso de realizar esta accion", "warning");
            // } else {
                document.getElementById("id").value = res.id;
                document.getElementById("usuario").value = res.usuario;
                document.getElementById("nombre").value = res.nombre;
                document.getElementById("genero").value = res.genero;
                document.getElementById("cargo").value = res.cargo;
                document.getElementById("claves").classList.add('d-none');
                // myModal.show();
                $("#nuevo_usuario").modal("show");
                tblUsuarios.ajax.reload();
            // }
        }
    }

}
function btnEliminarUsuario(id) {
    // alert(id);
    Swal.fire({
        title: '¿Esta seguro de la eliminacion?',
        text: "El usuario no se eliminara de forma permanente, solo cambia a estado inactivo",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Si',
        cancelButtonText: 'No'
    }).then((result) => {
        if (result.isConfirmed) {
            const url = base_url + "Usuarios/eliminar/" + id;
            const http = new XMLHttpRequest();
            http.open("GET", url, true);
            http.send();
            http.onreadystatechange = function () {
                if (this.readyState == 4 && this.status == 200) {
                    // console.log(this.responseText);
                    const res = JSON.parse(this.responseText);
                    if (res=='') {
                        alertas('No tiene permiso de eliminar', 'warning');
                    }else{
                        alertas(res.msg, res.icono);
                        tblUsuarios.ajax.reload();
                    }
                }
            }

        }
    })
}
function btnReingresarUsuario(id) {
    Swal.fire({
        title: '¿Estas seguro de reingresar?',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Si',
        cancelButtonText: 'No'
    }).then((result) => {
        if (result.isConfirmed) {
            const url = base_url + "Usuarios/reingresar/" + id;
            const http = new XMLHttpRequest();
            http.open("GET", url, true);
            http.send();
            http.onreadystatechange = function () {
                if (this.readyState == 4 && this.status == 200) {
                    const res = JSON.parse(this.responseText);
                    if (res=='') {
                        alertas("No tiene permiso de realizar esta accion", "warning");
                    } else {
                        tblUsuarios.ajax.reload();
                    alertas(res.msg, res.icono);
                    }
                }
            }

        }
    })
}
//--------------------------------------------------------
function frmVehiculo() {
    document.getElementById("tituloModal").innerHTML = "Registrar vehiculo";
    document.getElementById("btnAccion").innerHTML = "Registrar";
    document.getElementById("frmVehiculo").reset();
    $("#nuevo_vehiculo").modal("show");
    document.getElementById("id").value = "";
}
function registrarUsuario(e) {
    e.preventDefault();
    const usuario = document.getElementById("usuario");
    const nombre = document.getElementById("nombre");
    const clave = document.getElementById("clave");
    const confirmar = document.getElementById("confirmar");
    const genero = document.getElementById("genero");
    const cargo = document.getElementById("cargo");
    if (usuario.value == "" || nombre.value == "" || genero.value == ""|| cargo.value == "") {
        alertas('Todo los campos son obligatorios', 'warning');
    } else if (clave.value != confirmar.value) {
        alertas('Las contraseñas no coinciden', 'warning');
    } else {
        const url = base_url + "Usuarios/registrar";
        const frm = document.getElementById("frmUsuario");
        const http = new XMLHttpRequest();
        http.open("POST", url, true);
        http.send(new FormData(frm));
        http.onreadystatechange = function () {
            if (this.readyState == 4 && this.status == 200) {
                const res = JSON.parse(this.responseText);
                alertas(res.msg, res.icono);
                frm.reset();
                $("#nuevo_usuario").modal("hide");
                tblUsuarios.ajax.reload();
            }
        }
    }
}
function btnEditarUsuario(id) {
    document.getElementById("tituloModal").innerHTML = "Actualizar usuario";
    document.getElementById("btnAccion").innerHTML = "Modificar";
    const url = base_url + "Usuarios/editar/" + id;
    const http = new XMLHttpRequest();
    http.open("GET", url, true);
    http.send();
    http.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
            const res = JSON.parse(this.responseText);
            // if (res=='') {
            //     alertas("No tiene permiso de realizar esta accion", "warning");
            // } else {
                document.getElementById("id").value = res.id;
                document.getElementById("usuario").value = res.usuario;
                document.getElementById("nombre").value = res.nombre;
                document.getElementById("genero").value = res.genero;
                document.getElementById("cargo").value = res.cargo;
                document.getElementById("claves").classList.add('d-none');
                // myModal.show();
                $("#nuevo_usuario").modal("show");
                tblUsuarios.ajax.reload();
            // }
        }
    }

}
function btnEliminarUsuario(id) {
    // alert(id);
    Swal.fire({
        title: '¿Esta seguro de la eliminacion?',
        text: "El usuario no se eliminara de forma permanente, solo cambia a estado inactivo",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Si',
        cancelButtonText: 'No'
    }).then((result) => {
        if (result.isConfirmed) {
            const url = base_url + "Usuarios/eliminar/" + id;
            const http = new XMLHttpRequest();
            http.open("GET", url, true);
            http.send();
            http.onreadystatechange = function () {
                if (this.readyState == 4 && this.status == 200) {
                    // console.log(this.responseText);
                    const res = JSON.parse(this.responseText);
                    if (res=='') {
                        alertas('No tiene permiso de eliminar', 'warning');
                    }else{
                        alertas(res.msg, res.icono);
                        tblUsuarios.ajax.reload();
                    }
                }
            }

        }
    })
}
function btnReingresarUsuario(id) {
    Swal.fire({
        title: '¿Estas seguro de reingresar?',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Si',
        cancelButtonText: 'No'
    }).then((result) => {
        if (result.isConfirmed) {
            const url = base_url + "Usuarios/reingresar/" + id;
            const http = new XMLHttpRequest();
            http.open("GET", url, true);
            http.send();
            http.onreadystatechange = function () {
                if (this.readyState == 4 && this.status == 200) {
                    const res = JSON.parse(this.responseText);
                    if (res=='') {
                        alertas("No tiene permiso de realizar esta accion", "warning");
                    } else {
                        tblUsuarios.ajax.reload();
                    alertas(res.msg, res.icono);
                    }
                }
            }

        }
    })
}
function alertas(mensaje, icono) {
    Swal.fire({
        position: 'top-end',
        icon: icono,
        title: mensaje,
        showConfirmButton: false,
        timer: 2000
    })
}